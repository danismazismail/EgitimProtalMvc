﻿using FactoryPattern.Lab_1.Creator;
using FactoryPattern.Lab_1.Interface;
using FactoryPattern.Lab_2.Creator;

namespace FactoryPattern
{
    internal class Program
    {
        static void Main(string[] args)
        {
            #region Lab - 1
            //ProductCreator productCreator = new ProductCreator();

            //IProduct product;

            //for (int i = 1; i <= 12; i++)
            //{
            //    product = productCreator.FactoryMethod(i);
            //    Console.WriteLine($"Coffee Beans: {product.ShipFrom()}");
            //}
            #endregion


            #region Lab - 2

            #region DEPENDENCY INJECTION
            //1)DI -- Constructor'a değer atayarak enjekte etme
            SystemManager mailSystemManager = new SystemManager(new MailLoggerFactory());
            SystemManager dbSystemManager = new SystemManager(new DbLoggerFactory());
            #endregion

            #region METHOD INJECTION
            //Method Injection - Methoda parametre vererek enjekte etme
            //SystemManager mailSystemManager = new SystemManager();
            //mailSystemManager.SystemManagerDI(new MailLoggerFactory());
            //SystemManager dbSystemManager = new SystemManager();
            //dbSystemManager.SystemManagerDI(new DbLoggerFactory());
            #endregion

            #region PROPERTY INJECTION
            //Property Injection - property'e değere atayarak enjekte etme
            //SystemManager mailSystemManager = new SystemManager();
            //mailSystemManager.SystemManagerDI = new MailLoggerFactory();
            //SystemManager dbSystemManager = new SystemManager();
            //dbSystemManager.SystemManagerDI = new DbLoggerFactory();
            #endregion


            mailSystemManager.Logged();
            dbSystemManager.Logged();

            #endregion
        }
    }
}
