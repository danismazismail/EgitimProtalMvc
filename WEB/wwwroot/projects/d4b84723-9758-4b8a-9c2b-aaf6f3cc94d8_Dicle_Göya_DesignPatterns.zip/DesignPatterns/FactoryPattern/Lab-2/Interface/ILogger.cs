﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FactoryPattern.Lab_2.Interface
{
    public interface ILogger
    {
        void Log();
    }
}
