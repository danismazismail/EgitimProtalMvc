﻿using FactoryPattern.Lab_2.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FactoryPattern.Lab_2.Concrete
{
    public class DbLogger : ILogger
    {
        public void Log() => Console.WriteLine("Database log'u kaydedildi.");
    }
}
