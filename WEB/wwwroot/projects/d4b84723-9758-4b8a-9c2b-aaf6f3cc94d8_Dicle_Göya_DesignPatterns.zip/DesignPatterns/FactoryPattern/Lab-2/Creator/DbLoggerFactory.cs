﻿using FactoryPattern.Lab_2.Concrete;
using FactoryPattern.Lab_2.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FactoryPattern.Lab_2.Creator
{
    public class DbLoggerFactory : ILoggerFactory
    {
        public ILogger CreateLogger() => new DbLogger();
    }
}
