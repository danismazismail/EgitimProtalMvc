﻿using FactoryPattern.Lab_2.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FactoryPattern.Lab_2.Creator
{
    //Dependency => Bağımlılık
    //Dependency Inversion => Bağımlılıkları tersine çevir
    //Dependency Injection  => Nesneyi consturctor'da çağır ve field'a aktar.
    //Method Injection => NEsneyi, method aracılığıyla ç.ağır.
    //Property Injection
    public class SystemManager
    {
        private readonly ILoggerFactory _loggerFactory;

        public SystemManager(ILoggerFactory loggerFactory)
        {
            _loggerFactory = loggerFactory;
        }

        //Custom Method Injection
        //public ILoggerFactory SystemManagerDI(ILoggerFactory loggerFactory)
        //     => _loggerFactory = loggerFactory;


        //Property Injection
        //public ILoggerFactory SystemManagerDI
        //{
        //    get => _loggerFactory;
        //    set => _loggerFactory = value;
        //}

        public void Logged() => _loggerFactory.CreateLogger().Log();

    }
}
