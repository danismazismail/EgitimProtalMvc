﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdapterPattern.Concrete
{
    public class Adaptee
    {
        public void SpesificRequest()
        {
            Console.WriteLine("Bu bir özel istektir.");
        }
    }
}
