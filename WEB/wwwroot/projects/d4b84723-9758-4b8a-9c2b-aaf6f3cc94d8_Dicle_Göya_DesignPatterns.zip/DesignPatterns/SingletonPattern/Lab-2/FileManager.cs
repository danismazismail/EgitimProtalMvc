﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SingletonPattern.Lab_2
{
    public class FileManager
    {
        private static FileManager _fileManager;
        private FileManager() { }

        public static FileManager CreateObject
        {
            get
            {
                if (_fileManager == null)
                {
                    _fileManager = new FileManager();
                }
                return _fileManager;
            }
        }

        public void CreateLog() => Console.WriteLine("Log sisteme kaydedildi!");
    }
}
