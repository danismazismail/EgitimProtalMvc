﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SingletonPattern.Lab_1
{
    public class SystemManager
    {
        private static SystemManager _systemManager;

        private SystemManager() { } //Buradaki amaç bu sınıfın dışarıdan erişilerek instance çıkartılmasını engellemektir.
        //Sınıfın intance'ını dışardan üretemeyeceğiz çünkü constructor'ı private yaptık. Bunun yerine sınıfın kendi içerisinde kontrollü bir şekilde custom bir method ya da property aracılığıyla nesnenin üretimini kontrol altına aldık.

        public static SystemManager CreateInstance()
        {
            //Uygulmamanın herhangi bir yerinde "SystemManager." diyerek CreateInstance() methodunu çağırabilirim. Bu method bana SysteManager sınıfının instance'ını bir şart doğrultusunda yaratır ya da var olanı teslim eder.
            if (_systemManager == null) //Eğer _systemManager field'e içerisi boşsa
            {
                _systemManager = new SystemManager(); //nesne üretilir.
            }
            //_systemManager nesnesi zaten dolu ise direk bize onu teslim eder.
            return _systemManager; //nesne dönülür.
        }

        public void CreateLog() => Console.WriteLine("Log sisteme kaydedildi!");
    }
}
