﻿using SingletonPattern.Lab_1;
using SingletonPattern.Lab_2;

namespace SingletonPattern
{
    internal class Program
    {
        static void Main(string[] args)
        {
            #region Lab - 1 - Method ile
            //İki nesnenide HashCode'ları aynı olacaktır. Çünkü ikiside arkaplan aynı nesnedir.
            SystemManager systemManager1 = SystemManager.CreateInstance();
            SystemManager systemManager2 = SystemManager.CreateInstance();

            Console.WriteLine(systemManager1.GetHashCode());
            Console.WriteLine(systemManager2.GetHashCode());

            systemManager1.CreateLog();
            SystemManager.CreateInstance().CreateLog();
            #endregion

            #region Lab - 2 - Property ile
            FileManager fileManager1 = FileManager.CreateObject;
            FileManager fileManager2 = FileManager.CreateObject;

            Console.WriteLine(fileManager1.GetHashCode());
            Console.WriteLine(fileManager2.GetHashCode());

            fileManager1.CreateLog();
            FileManager.CreateObject.CreateLog();
            #endregion
        }
    }
}
