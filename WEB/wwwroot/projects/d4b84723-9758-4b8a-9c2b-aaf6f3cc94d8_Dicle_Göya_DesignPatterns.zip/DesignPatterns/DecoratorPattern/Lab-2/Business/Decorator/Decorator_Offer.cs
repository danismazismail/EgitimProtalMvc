﻿using DecoratorPattern.Lab_2.Business.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DecoratorPattern.Lab_2.Business.Decorator
{
    public class Decorator_Offer : IOfferBusiness
    {
        private readonly IOfferBusiness _offerBusiness;

        public Decorator_Offer(IOfferBusiness offerBusiness)
        {
            _offerBusiness = offerBusiness;
        }

        public double GetPrice() => _offerBusiness.GetPrice() * 0.8;
        
    }
}
