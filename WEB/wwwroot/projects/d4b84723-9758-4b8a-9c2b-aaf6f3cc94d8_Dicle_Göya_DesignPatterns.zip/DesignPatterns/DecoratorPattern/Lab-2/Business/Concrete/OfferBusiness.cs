﻿using DecoratorPattern.Lab_2.Abstract;
using DecoratorPattern.Lab_2.Business.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DecoratorPattern.Lab_2.Business.Concrete
{
    public class OfferBusiness : IOfferBusiness
    {
        private readonly BaseCar _baseCar;

        public OfferBusiness(BaseCar baseCar)
        {
            _baseCar = baseCar;
        }

        public double GetPrice() => _baseCar.Price;
    }
}
