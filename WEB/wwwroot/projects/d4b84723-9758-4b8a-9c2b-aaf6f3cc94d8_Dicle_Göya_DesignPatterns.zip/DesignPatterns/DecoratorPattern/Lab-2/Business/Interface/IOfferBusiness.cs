﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DecoratorPattern.Lab_2.Business.Interface
{
    public interface IOfferBusiness
    {
        double GetPrice();
    }
}
