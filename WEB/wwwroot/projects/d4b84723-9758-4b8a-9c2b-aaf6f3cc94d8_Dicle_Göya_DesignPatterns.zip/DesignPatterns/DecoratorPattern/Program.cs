﻿using DecoratorPattern.Lab_1.Concrete;
using DecoratorPattern.Lab_1.Interface;
using DecoratorPattern.Lab_2.Business.Concrete;
using DecoratorPattern.Lab_2.Business.Decorator;
using DecoratorPattern.Lab_2.Business.Interface;
using DecoratorPattern.Lab_2.Concrete;

namespace DecoratorPattern
{
    internal class Program
    {
        static void Main(string[] args)
        {
            #region Lab - 1
            //IBilesen bilesen = new Bilesen();

            ////Ham Hali
            ////Console.WriteLine(bilesen.Operation());

            ////Dekorasyon - 1
            //IBilesen dekore1 = new Decorator_A(bilesen);
            //Console.WriteLine(dekore1.Operation());

            ////Dekorasyon - 2
            //IBilesen dekore2 = new Decorator_B(bilesen);
            //Console.WriteLine(dekore2.Operation());
            #endregion

            #region Lab - 2
            SUV suv = new SUV();
            suv.Brand = "Audi";
            suv.Model = "Q7";
            suv.Price = 9000000;

            //Normal Fiyat
            IOfferBusiness offerBusiness = new OfferBusiness(suv);
            Console.WriteLine("Liste fiyatı: " + offerBusiness.GetPrice());

            //İndirimli Fiyat
            IOfferBusiness decorator = new Decorator_Offer(offerBusiness);
            Console.WriteLine("Size özel: " + decorator.GetPrice());

            #endregion

        }
    }
}
